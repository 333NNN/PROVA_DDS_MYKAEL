/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nata_q2;

import java.io.IOException;

/**
 *
 * @author ncunha
 */
public class Nata_Q2 {

    public static void main(String[] args) throws IOException {
                
        System.out.println("Hello World!");
        
        
    }
}
